//
//  CoversCell.swift
//  BookShelf
//
//  Created by Arely Correa on 4/5/24.
//

import Foundation
import UIKit
import Nuke

class CoversCell: UICollectionViewCell {
    
    //@IBOutlet weak var bookImageView: UIImageView!
    //@IBOutlet weak var titleLabel: UILabel!
    //@IBOutlet weak var authorNameLabel: UILabel!
    //@IBOutlet weak var bookImage: UIImageView!
    @IBOutlet weak var coversImageView: UIImageView!
    
    
    /// Configures the cell's UI for the given book.
    func configure(with book: Book) {

        // Load image async via Nuke library image loading helper method
        Nuke.loadImage(with: book.cover as ImageRequestConvertible, into: coversImageView)
    }

}
