//
//  DetailViewController.swift
//  lab-tunley
//
//  Created by Charlie Hieger on 12/5/22.
//

import UIKit
import Nuke

class DetailViewController: UIViewController {

    @IBOutlet weak var bookImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var pageCountLabel: UILabel!
    @IBOutlet weak var genreLabel: UILabel!
    @IBOutlet weak var summaryLabel: UILabel!
    
    var book: Book!

    override func viewDidLoad() {
        super.viewDidLoad()

        Nuke.loadImage(with: book.cover as ImageRequestConvertible, into: bookImageView)
        titleLabel.text = book.title
        authorLabel.text = book.author
        pageCountLabel.text = String(book.pagecount)
        genreLabel.text = book.genre
        summaryLabel.text = book.summary

        // Create a date formatter to style our date and convert it to a string
        

    }


}
