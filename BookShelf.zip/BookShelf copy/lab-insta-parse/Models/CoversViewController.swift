//
//  CoversViewController.swift
//  BookShelf
//
//  Created by Arely Correa on 4/5/24.
//

import Foundation
import Nuke
import UIKit
//
class CoversViewController: UIViewController, UICollectionViewDataSource {
   
    var books : [Book] = []
    
   
    @IBOutlet weak var coverCollectionView: UICollectionView!
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

        // the number of items shown should be the number of albums we have.
        books.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        // Get a collection view cell (based in the identifier you set in storyboard) and cast it to our custom AlbumCell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CoversCell", for: indexPath) as! CoversCell

        // Use the indexPath.item to index into the albums array to get the corresponding album
        let books = books[indexPath.item]

        // Get the artwork image url
        let imageUrl = books.cover

        // Set the image on the image view of the cell
        Nuke.loadImage(with: imageUrl, into: cell.coversImageView)

        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // TODO: Pt 1 - Set mockBooks property with mock mockBooks array
        books = Book.mockBooks
        print(books)

        coverCollectionView.dataSource = self
        
        let layout = coverCollectionView.collectionViewLayout as! UICollectionViewFlowLayout
        
                // The minimum spacing between adjacent cells (left / right, in vertical scrolling collection)
                // Set this to taste.
                layout.minimumInteritemSpacing = 4
        
                // The minimum spacing between adjacent cells (top / bottom, in vertical scrolling collection)
                // Set this to taste.
                layout.minimumLineSpacing = 4
        
                // Set this to however many columns you want to show in the collection.
                let numberOfColumns: CGFloat = 3
        
                // Calculate the width each cell need to be to fit the number of columns, taking into account the spacing between cells.
                let width = (coverCollectionView.bounds.width - layout.minimumInteritemSpacing * (numberOfColumns - 1)) / numberOfColumns
        
                // Set the size that each tem/cell should display at
                layout.itemSize = CGSize(width: width, height: width)
                
        
    }

    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // TODO: Pt 1 - Pass the selected Book to the detail view controller

        // Get the cell that triggered the segue
        if let cell = sender as? UICollectionViewCell,
           // Get the index path of the cell from the table view
           let indexPath = coverCollectionView.indexPath(for: cell),
           // Get the detail view controller
           let detailViewController = segue.destination as? DetailViewController {

            // Use the index path to get the associated Book
            let book = books[indexPath.row]

            // Set the Book on the detail view controller
            detailViewController.book = book
        }
    }

    
    
    // Assuming you have a collection view outlet connected in your storyboard
//    @IBOutlet weak var collectionView: UICollectionView!
//    
//    var books : [Book] = []
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        books = Book.mockBooks
//        // Set collection view data source
//        collectionView.dataSource = self
//        
//        // Reload the collection view to reflect the changes
//        collectionView.reloadData()
//    }
//    
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return books.count
//    }
//    
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CoversCell", for: indexPath) as! CoversCell
//        
//        // Get the book corresponding to the current indexPath
//        let book = books[indexPath.row]
//        cell.configure(with: <#T##Book#>)
//        
//        // Get the cover URL from the book
//        
//        // Load the cover image using Nuke
//        //Nuke.loadImage(with: coverURL, into: cell.bookImageView)
//        
//        return cell
    }

    
    
    //var cover: [Cover] = []
    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        
//        // Do any additional setup after loading the view.
////        let url = URL(string: "https://api.themoviedb.org/3/movie/now_playing?api_key=a891cd38d8d03ca7b1ebaf07bddcdf34")!
////        
////        let request = URLRequest(url: url)
////        
////        let task = URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
////            
////            // Handle any errors
////            if let error = error {
////                print("❌ Network error: \(error.localizedDescription)")
////            }
////            
////            // Make sure we have data
////            guard let data = data else {
////                print("❌ Data is nil")
////                return
////            }
//            
//           
////            do {
////                let decoder = JSONDecoder()
////                // Try to parse the response into our custom model
////                let response = try decoder.decode(PostersSearchResponse.self, from: data)
////                let cover = response.results
////                print(cover)
////                DispatchQueue.main.async {
////                    self?.cover = cover
////                    self?.collectionView.reloadData()
////                }
////            }
////            
////            catch let parsingError{
////                print(parsingError)
////                //print(error.localizedDescription)
//            }
//        }
//        
//        // Initiate the network request
////        task.resume()
////        collectionView.dataSource = self
//        // Get a reference to the collection view's layout
//        // We want to dynamically size the cells for the available space and desired number of columns.
//        // NOTE: This collection view scrolls vertically, but collection views can alternatively scroll horizontally.
//        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
//        
//        // The minimum spacing between adjacent cells (left / right, in vertical scrolling collection)
//        // Set this to taste.
//        layout.minimumInteritemSpacing = 4
//        
//        // The minimum spacing between adjacent cells (top / bottom, in vertical scrolling collection)
//        // Set this to taste.
//        layout.minimumLineSpacing = 4
//        
//        // Set this to however many columns you want to show in the collection.
//        let numberOfColumns: CGFloat = 3
//        
//        // Calculate the width each cell need to be to fit the number of columns, taking into account the spacing between cells.
//        let width = (collectionView.bounds.width - layout.minimumInteritemSpacing * (numberOfColumns - 1)) / numberOfColumns
//        
//        // Set the size that each tem/cell should display at
//        layout.itemSize = CGSize(width: width, height: width)
//        
//        
//        
//        
//    }
////    var tracks: [Track] = []
//    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        // TODO: Pt 1 - Pass the selected track to the detail view controller
//        // Get the cell that triggered the segue
//        if let cell = sender as? UICollectionViewCell,
//           // Get the index path of the cell from the table view
//           let indexPath = collectionView.indexPath(for: cell),
//           // Get the detail view controller
//           let detailViewController2 = segue.destination as? DetailViewController2 {
//
//            // Use the index path to get the associated track
//            let cover = cover[indexPath.row]
//
//            // Set the track on the detail view controller
//            detailViewController2.cover = cover
//        }
//
//    }
    
    

