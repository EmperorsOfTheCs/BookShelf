import Foundation

// TODO: Pt 1 - Create a mockBooks model struct
struct Book: Decodable{
    let title: String
    let author: String
    let genre: String
    let pagecount: Int
    let cover:URL
    let summary: String
}


extension Book {

    /// An array of mock mockBookss
    static var mockBooks: [Book]  = [
        
        Book(title: "To Kill a Mockingbird",
            author: "Harper Lee",
            genre: "Fiction",
            pagecount: 281,
            cover:URL(string: "https://m.media-amazon.com/images/M/MV5BNmVmYzcwNzMtMWM1NS00MWIyLThlMDEtYzUwZDgzODE1NmE2XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg")!,
            summary: "To Kill a Mockingbird is a novel by Harper Lee published in 1960. It was immediately successful, winning the Pulitzer Prize, and has become a classic of modern American literature."),
        Book(title: "1984",
            author: "George Orwell",
            genre: "Science Fiction",
            pagecount: 328,
            cover:URL(string: "https://m.media-amazon.com/images/I/81m-yfhwlfL._AC_UF1000,1000_QL80_.jpg")!,
            summary: "1984 is a dystopian novel by George Orwell published in 1949. The story takes place in an imagined future where the world is divided into three superpowers."
          ),
        Book(title: "The Great Gatsby",
            author: "F. Scott Fitzgerald",
            genre: "Fiction",
            pagecount: 180,
            cover:URL(string: "https://m.media-amazon.com/images/I/81QuEGw8VPL._AC_UF1000,1000_QL80_.jpg")!,
            summary: "The Great Gatsby is a novel written by American author F. Scott Fitzgerald that follows a cast of characters living in the fictional towns of West Egg and East Egg on prosperous Long Island in the summer of 1922."
          ),
        Book(title: "Moby-Dick",
            author: "Herman Melville",
            genre: "Adventure",
            pagecount: 544,
            cover:URL(string: "https://m.media-amazon.com/images/I/51aV053NRjL._AC_UF1000,1000_QL80_.jpg")!,
            summary: "Moby-Dick; or, The Whale is an 1851 novel by American writer Herman Melville. The book is the sailor Ishmael's narrative of the obsessive quest of Ahab, captain of the whaling ship Pequod, for revenge on Moby Dick, the giant white sperm whale that on the ship's previous voyage bit off Ahab's leg at the knee."
          ),
          Book(title: "Pride and Prejudice",
            author: "Jane Austen",
            genre: "Romance",
            pagecount: 279,
            cover:URL(string: "https://images.penguinrandomhouse.com/cover/9780593622452")!,
            summary: "Pride and Prejudice is a romantic novel of manners written by Jane Austen in 1813. The novel follows the character development of Elizabeth Bennet, the dynamic protagonist of the book who learns about the repercussions of hasty judgments and eventually comes to appreciate the difference between superficial goodness and actual goodness."
          ),
        Book(title: "The Catcher in the Rye",
            author: "J.D. Salinger",
            genre: "Fiction",
            pagecount: 277,
            cover:URL(string: "https://m.media-amazon.com/images/I/8125BDk3l9L._AC_UF1000,1000_QL80_.jpg")!,
            summary: "The Catcher in the Rye is a novel by J. D. Salinger, partially published in serial form in 1945–1946 and as a novel in 1951. It was originally intended for adults, but is often read by adolescents for its themes of angst, alienation, and as a critique on superficiality in society."
            ),
        Book(title: "Harry Potter and the Philosopher's Stone",
            author: "J.K. Rowling",
            genre: "Fantasy",
            pagecount: 223,
            cover:URL(string: "https://m.media-amazon.com/images/I/81q77Q39nEL._AC_UF1000,1000_QL80_.jpg")!,
            summary: "Harry Potter and the Philosopher's Stone is a fantasy novel written by British author J. K. Rowling. The book follows Harry Potter, a young wizard who discovers his magical heritage on his eleventh birthday when he receives a letter of acceptance to Hogwarts School of Witchcraft and Wizardry."
          ),
            Book(title: "The Hobbit",
            author: "J.R.R. Tolkien",
            genre: "Fantasy",
            pagecount: 310,
            cover:URL(string: "https://m.media-amazon.com/images/I/712cDO7d73L._AC_UF1000,1000_QL80_.jpg")!,
            summary: "The Hobbit, or There and Back Again is a children's fantasy novel by English author J. R. R. Tolkien. It was published on 21 September 1937 to wide critical acclaim, being nominated for the Carnegie Medal and awarded a prize from the New York Herald Tribune for best juvenile fiction."
          ),Book(title: "The Da Vinci Code",
            author: "Dan Brown",
            genre: "Mystery",
            pagecount: 489,
            cover:URL(string: "https://m.media-amazon.com/images/I/91p-Z1BLufL._AC_UF894,1000_QL80_.jpg")!,
            summary: "The Da Vinci Code is a mystery thriller novel by Dan Brown. It follows symbologist Robert Langdon and cryptologist Sophie Neveu after a murder in the Louvre Museum in Paris causes them to become involved in a battle between the Priory of Sion and Opus Dei over the possibility of Jesus Christ having been married to Mary Magdalene."
          ),
          Book(title: "The Lord of the Rings",
            author: "J.R.R. Tolkien",
            genre: "Fantasy",
            pagecount: 1178,
            cover:URL(string: "https://m.media-amazon.com/images/I/81nV6x2ey4L._AC_UF1000,1000_QL80_.jpg")!,
            summary: "The Lord of the Rings is an epic high-fantasy novel written by English author J. R. R. Tolkien. The story began as a sequel to Tolkien's 1937 fantasy novel The Hobbit, but eventually developed into a much larger work."
          ),
          Book(title: "Alice's Adventures in Wonderland",
            author: "Lewis Carroll",
            genre: "Fantasy",
            pagecount: 192,
            cover:URL(string: "https://m.media-amazon.com/images/I/81SbkDYM5BL._AC_UF1000,1000_QL80_.jpg")!,
            summary: "Alice's Adventures in Wonderland is an 1865 novel by English author Lewis Carroll. The story tells of a young girl named Alice who falls through a rabbit hole into a subterranean fantasy world populated by peculiar, anthropomorphic creatures."
          ),
        Book(title: "The War of the Worlds",
            author: "H.G. Wells",
            genre: "Science Fiction",
            pagecount: 192,
            cover:URL(string: "https://m.media-amazon.com/images/I/71GNnwrqYmL._AC_UF1000,1000_QL80_.jpg")!,
            summary: "The War of the Worlds is a science fiction novel by English author H. G. Wells, first serialized in 1897 by Pearson's Magazine in the UK and by Cosmopolitan magazine in the US. The novel's first appearance in hardcover was in 1898 from publisher William Heinemann of London."
          ),
          Book(title:"A Tale of Two Cities",
            author: "Charles Dickens",
            genre: "Historical Fiction",
            pagecount: 341,
            cover:URL(string: "https://m.media-amazon.com/images/I/91C0MECqJ+L._AC_UF1000,1000_QL80_.jpg")!,
            summary: "A Tale of Two Cities is an 1859 historical novel by Charles Dickens, set in London and Paris before and during the French Revolution. The novel tells the story of the French Doctor Manette, his 18-year-long imprisonment in the Bastille in Paris and his release to live in London with his daughter Lucie, whom he had never met."
          ),
            Book(title: "The Adventures of Sherlock Holmes",
            author: "Arthur Conan Doyle",
            genre: "Mystery",
            pagecount: 307,
            cover:URL(string: "https://m.media-amazon.com/images/I/81tNnqcHxlL._AC_UF1000,1000_QL80_.jpg")!,
            summary: "The Adventures of Sherlock Holmes is a collection of twelve short stories by Arthur Conan Doyle, featuring his fictional detective Sherlock Holmes. It was first published on 14 October 1892; the individual stories had been serialised in The Strand Magazine between July 1891 and June 1892."
          ),
          Book(title:"Les Misérables",
            author: "Victor Hugo",
            genre: "Historical Fiction",
            pagecount: 1232,
            cover:URL(string: "https://m.media-amazon.com/images/I/71eQUDwCBfL._AC_UF1000,1000_QL80_.jpg")!,
            summary: "Les Misérables is a French historical novel by Victor Hugo, first published in 1862, that is considered one of the greatest novels of the 19th century. In the English-speaking world, the novel is usually referred to by its original French title."
          ),
      
        Book(
          title: "The Count of Monte Cristo",
          author: "Alexandre Dumas",
          genre: "Adventure",
          pagecount: 1276,
          cover:URL(string: "https://m.media-amazon.com/images/I/81bNjA3corL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "The Count of Monte Cristo is an adventure novel by French author Alexandre Dumas completed in 1844. It is one of the author's more popular works, along with The Three Musketeers. The story takes place in France, Italy, and islands in the Mediterranean during the historical events of 1815–1839: the era of the Bourbon Restoration through the reign of Louis-Philippe of France."
        ),
        Book(
          title: "War and Peace",
          author: "Leo Tolstoy",
          genre: "Historical Fiction",
          pagecount: 1392,
          cover:URL(string: "https://m.media-amazon.com/images/I/71wXZB-VtBL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "War and Peace is a novel by the Russian author Leo Tolstoy, published serially, then in its entirety in 1869. It is regarded as one of Tolstoy's finest literary achievements and remains a classic of world literature."
        ),
        Book(
          title: "Crime and Punishment",
          author: "Fyodor Dostoevsky",
          genre: "Psychological Fiction",
          pagecount: 671,
          cover:URL(string: "https://m.media-amazon.com/images/I/71O2XIytdqL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "Crime and Punishment is a novel by the Russian author Fyodor Dostoevsky. It was first published in the literary journal The Russian Messenger in twelve monthly installments during 1866."
        ),
        Book(
          title: "Don Quixote",
          author: "Miguel de Cervantes",
          genre: "Satire",
          pagecount: 1056,
          cover:URL(string: "https://m.media-amazon.com/images/I/411WFSFEMJL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "Don Quixote is a Spanish novel by Miguel de Cervantes. Published in two parts in 1605 and 1615, it is considered the most influential work of literature from the Spanish Golden Age and the entire Spanish literary canon."
        ),
        Book(
          title: "Anna Karenina",
          author: "Leo Tolstoy",
          genre: "Historical Fiction",
          pagecount: 964,
          cover:URL(string: "https://m.media-amazon.com/images/I/91F9WNEThJL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "Anna Karenina is a novel by the Russian author Leo Tolstoy, first published in book form in 1878. Many writers consider Anna Karenina the greatest work of literature ever written, and Tolstoy himself called it his first true novel."
        ),
        Book(
          title: "The Odyssey",
          author: "Homer",
          genre: "Epic Poetry",
          pagecount: 478,
          cover:URL(string: "https://m.media-amazon.com/images/I/71FC1AcWTKL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "The Odyssey is one of two major ancient Greek epic poems attributed to Homer. It is one of the oldest extant works of literature still read by contemporary audiences."
        ),
        Book(
          title: "One Hundred Years of Solitude",
          author: "Gabriel García Márquez",
          genre: "Magical Realism",
          pagecount: 417,
          cover:URL(string: "https://m.media-amazon.com/images/I/81MI6+TpYkL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "One Hundred Years of Solitude is a landmark 1967 novel by Colombian author Gabriel García Márquez that tells the multi-generational story of the Buendía family, whose patriarch, José Arcadio Buendía, founded the town of Macondo, a fictitious town in the country of Colombia."
        ),
        Book(
          title: "The Brothers Karamazov",
          author: "Fyodor Dostoevsky",
          genre: "Philosophical Fiction",
          pagecount: 796,
          cover:URL(string: "https://m.media-amazon.com/images/I/71OZJsgZzQL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "The Brothers Karamazov is a novel by Fyodor Dostoevsky, first published in 1880. It is the final novel written by Dostoevsky and is considered one of his greatest works."
            ),
            Book(
          title: "The Picture of Dorian Gray",
          author: "Oscar Wilde",
          genre: "Gothic Fiction",
          pagecount: 198,
          cover:URL(string: "https://m.media-amazon.com/images/I/41XYp5hDDBL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "The Picture of Dorian Gray is a Gothic and philosophical novel by Oscar Wilde, first published complete in the July 1890 issue of Lippincott's Monthly Magazine. The magazine's editor feared the story was indecent, and without Wilde's knowledge, deleted roughly five hundred words before publication."
            ),
            Book(
          title: "Little Women",
          author: "Louisa May Alcott",
          genre: "Coming-of-Age Fiction",
          pagecount: 759,
          cover:URL(string: "https://m.media-amazon.com/images/I/91j2nOoYm0L._AC_UF1000,1000_QL80_.jpg")!,
          summary: "Little Women is a novel by American author Louisa May Alcott, which was originally published in two volumes in 1868 and 1869. Alcott wrote the book over several months at the request of her publisher. The story follows the lives of the four March sisters—Meg, Jo, Beth, and Amy—and details their passage from childhood to womanhood. It is loosely based on the lives of the author and her three sisters."
            ),
            Book(
          title: "Frankenstein",
          author: "Mary Shelley",
          genre: "Gothic Horror",
          pagecount: 280,
          cover:URL(string: "https://m.media-amazon.com/images/I/81EU992zdwL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "Frankenstein; or, The Modern Prometheus is a novel written by English author Mary Shelley. The story revolves around Victor Frankenstein, who, at the age of 17, discovers how to create life and creates a being in the likeness of man, but larger than average and more powerful."
            ),
            Book(
          title: "Wuthering Heights",
          author: "Emily Brontë",
          genre: "Gothic Fiction",
          pagecount: 342,
          cover:URL(string: "https://m.media-amazon.com/images/I/51UBcTq-CGL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "Wuthering Heights is a novel by Emily Brontë published in 1847 under her pseudonym 'Ellis Bell'. It is her only finished novel. It is set in Yorkshire and tells the story of Heathcliff, a foundling taken in by the Earnshaw family, who develops an intense relationship with his foster sister, Cathy."
            ),
            Book(
          title: "Dracula",
          author: "Bram Stoker",
          genre: "Gothic Horror",
          pagecount: 418,
          cover:URL(string: "https://m.media-amazon.com/images/I/61w70l39W9L._AC_UF1000,1000_QL80_.jpg")!,
          summary: "Dracula is an 1897 Gothic horror novel by Irish author Bram Stoker. It introduced the character of Count Dracula and established many conventions of subsequent vampire fantasy."
            ),
            Book(
          title: "Anne of Green Gables",
          author: "Lucy Maud Montgomery",
          genre: "Children's Literature",
          pagecount: 429,
          cover:URL(string: "https://m.media-amazon.com/images/I/71mKX08j5OL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "Anne of Green Gables is a novel by Canadian author Lucy Maud Montgomery. Written for all ages, it has been considered a classic children's novel since the mid-20th century. It recounts the adventures of Anne Shirley, an 11-year-old orphan girl who is mistakenly sent to Matthew and Marilla Cuthbert, a middle-aged brother and sister who had intended to adopt a boy to help them on their farm in the fictional town of Avonlea on Prince Edward Island."
            ),
            Book(
          title: "The Little Prince",
          author: "Antoine de Saint-Exupéry",
          genre: "Children's Literature",
          pagecount: 83,
          cover:URL(string: "https://m.media-amazon.com/images/I/71OZY035QKL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "The Little Prince, first published in 1943, is a novella and the most famous work of the French writer and aviator Antoine de Saint-Exupéry. The story follows a young prince who visits various planets in space, including Earth, and addresses themes of loneliness, friendship, love, and loss."
            ),
            Book(
          title: "Charlotte's Web",
          author: "E.B. White",
          genre: "Children's Literature",
          pagecount: 192,
          cover:URL(string: "https://m.media-amazon.com/images/I/71Mn5a73FqL._AC_UF1000,1000_QL80_.jpg")!,
          summary: "Charlotte's Web is a children's novel by American author E. B. White and illustrated by Garth Williams; it was published on October 15, 1952, by Harper & Brothers. The novel tells the story of a livestock pig named Wilbur and his friendship with a barn spider named Charlotte. When Wilbur is in danger of being slaughtered by the farmer, Charlotte writes messages praising Wilbur in her web in order to persuade the farmer to let him live."
        ),
  
     ]
    }
