//
//  Cover.swift
//  BookShelf
//
//  Created by Arely Correa on 4/7/24.
//

import Foundation

struct CoverSearchResponse: Decodable {
    let results: [Cover]
}

struct Cover: Decodable {
    let cover: URL
}
